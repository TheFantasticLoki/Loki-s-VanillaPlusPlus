# FSEE

It stands for `FokaStudio's Ender Expansion`
[hr]
**FokaStudio's Ender Expansion** *(or **FSEE** for short)* is a Minecraft 1.19 worldgen datapack that focuses on rehauling The End dimension in a new, unique and fairly lively way.

FSEE started off as a direct port of [Far End](https://www.planetminecraft.com/data-pack/far-end-ender-expansion-datapack-v0-1/), for a server called Azalea Network *(today known as [Riptide Network](https://info.riptide-mc.network/), you should definitely check it out!)*, but grew into its own independent project as time passed.

Needless to say, **the pack is now nothing like its predecessor**. Everything has changed drastically, with more changes to the original being made each day.
